For each exercise Open the index.html file with Live Server. The databases are set already.


If you wish to do it with the given server.js and the data folder:
    For each exercise put the corresponding json file FROM the 'databases' folder TO the 'data' folder.
    Launch the server by opening the Terminal and writing 'node server'. Open the localhost server with ctrl + click.
    In the app.js file of the exercise make the changes necessary (replace the url in the fetch function) to acquire the data from the server. 
    Close the server by pressing ctrl+C