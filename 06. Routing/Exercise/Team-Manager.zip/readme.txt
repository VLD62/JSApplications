Steps to follow:

1. npm init
2. npm install sammy
3. npm install jquery
4. npm install bootstrap
5. npm install handlebars
6. npm install lite-server -g
7. After all libraries are installed start the server in same folder by typing in cmd: lite-server 